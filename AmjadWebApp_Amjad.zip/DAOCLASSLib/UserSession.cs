﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOCLASSLib
{
    public class UserSession
    {
        public int userid { get; set; }
        public string userName { get; set; }
        public string emailAddress { get; set; }
        public string AccountTye { get; set; }
    }
}
